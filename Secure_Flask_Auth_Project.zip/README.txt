
Secure Flask Authentication Mini Project

Features:
- Password Hashing
- Parameterized Queries
- Input Validation
- Logging
- Session Management
- No Debug Mode

Run:
1. pip install -r requirements.txt
2. python app.py
